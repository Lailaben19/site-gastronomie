/*Récupère les éléments du carrousel*/
const slides = document.querySelector('.slides');
const slideWidth = document.querySelector('.slide').offsetWidth;

// Défilement automatique du carrousel
let currentIndex = 0; // Index de la diapositive actuelle

function nextSlide() {
    currentIndex++;
    if (currentIndex >= slides.children.length) {
        currentIndex = 0; // Revenir à la première diapositive si on atteint la fin
    }
    const newPosition = -currentIndex * slideWidth;
    slides.style.left = newPosition + 'px'; // Déplacer le carrousel vers la prochaine diapositive
}

// Démarre le défilement automatique
setInterval(nextSlide, 5000); // Change de diapositive toutes les 5 secondes (5000 ms)