<?php 
session_start();
if (isset($_SESSION['user'])){
    header("Location: index.php");
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <link rel="icon" type="image/x-icon" href="images/logo.jpeg">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion</title>
    <link rel="stylesheet" href="css/style-connexion.css">
    
</head>
    <body>
    <header>
    <nav>
                <img src="images/logo.jpeg" alt="logo" class="logo"></img>
                <a href="index.php">
                    <h3>Accueil</h3>
                </a>
                
                <?php 
                if(isset($_SESSION["user"])){
                    echo '<a href="mes_recettes.php"><h3>Mes recettes</h3></a>';
                }else{
                    echo '<a href="recette.php"><h3>Recettes</h3></a>';
                }
                ?>


                <a href="apropos.php">
                    <h3>À Propos</h3>
                </a>
                <a href="contact.php">
                    <h3>contact</h3>
                </a>

                
                <?php 
                if(isset($_SESSION["user"])){
                    echo '<a href="monprofil.php"><h3>Mon Profil</h3></a>';
                }else{
                    echo '<a href="connexion.php"><h3>Se connecter</h3></a>';
                }
                if(isset($_SESSION["user"])){
                    echo '<a href="deconnexion.php"><h3>Se déconnecter</h3></a>';
                }
                ?>
            </nav>
    </header>
    <section>
    <form action="authentification.php" method="post" class="box">
    <h1>Connexion</h1>
    <h3>Email:</h3>
    <input type="email" name="email">
    <h3>Mot de passe :</h3>
    <input type="password" name="motdepasse">
    <input type="submit" value="Se connecter">
    <p>Vous avez pas de compte ?</p>
        <a href="inscription.php">Créer un compte</a>
    <p id="error-message"><?php
                                                if (isset($_GET['error'])){
                                                    echo '<div class="alert alert-danger" role="alert">' . htmlspecialchars($_GET['error']) . '</div>';
                                                }elseif (isset($_GET['success'])){
                                                    echo '<div class="alert alert-success" role="alert">' . htmlspecialchars($_GET['success']) . '</div>';
                                                }
                                                ?></p> <!-- Message d'erreur -->
</form>
    </section> 

    <footer class="footer">
    <div class="footer-container">
        <div class="footer-section">
            <h3>Gastronomic Adventure</h3>
            <p>Explorez de nouvelles aventures gastronomiques avec nous !</p>
        </div>
        <div class="footer-section">
            <h3>Restons connectés</h3>
            <ul class="social-media">
                <li><a href="instagram.html"><i class="fab fa-instagram"></i> Instagram</a></li>
                <li><a href="facebook.html"><i class="fab fa-facebook"></i> Facebook</a></li>
                <li><a href="tiktok.html"><i class="fab fa-tiktok"></i> TikTok</a></li>
            </ul>
        </div>
        <div class="footer-section">
            <h3>Contactez-nous</h3>
            <ul class="contact-info">
                <li><i class="fas fa-envelope"></i> Email: contact@gastronomicadventure.com</li>
                <li><i class="fas fa-phone"></i> Téléphone: +33 (234) 567-89</li>
                <li><i class="fas fa-map-marker-alt"></i> Adresse: 123 Rue Principale, Bordeaux</li>
            </ul>
        </div>
    </div>
</footer>
</body>
</html>
