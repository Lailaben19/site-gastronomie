<?php 
session_start();
if (!isset($_SESSION['user'])){
    header("Location: connexion.php?error=Vous devez vous connecter pour accéder à cette page.");
}
?>
<!DOCTYPE html>
<html lang="fr">

<head>
    <link rel="icon" type="image/x-icon" href="images/logo.jpeg">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recettes</title>
    <link rel="stylesheet" href="css/style-mes_recettes.css">

</head>

<header>
<nav>
                <img src="images/logo.jpeg" alt="logo" class="logo"></img>
                <a href="index.php">
                    <h3>Accueil</h3>
                </a>
                <?php 
                if(isset($_SESSION["user"])){
                    echo '<a href="mes_recettes.php"><h3>Mes recettes</h3></a>';
                }else{
                    echo '<a href="recette.php"><h3>Recettes</h3></a>';
                }
                ?>


                <a href="apropos.php">
                    <h3>À Propos</h3>
                </a>
                <a href="contact.php">
                    <h3>contact</h3>
                </a>

                
                <?php 
                if(isset($_SESSION["user"])){
                    echo '<a href="monprofil.php"><h3>Mon Profil</h3></a>';
                }else{
                    echo '<a href="connexion.php"><h3>Se connecter</h3></a>';
                }
                if(isset($_SESSION["user"])){
                    echo '<a href="deconnexion.php"><h3>Se déconnecter</h3></a>';
                }
                ?>
            </nav>
</header>

<body>
    <section>
    <h2>Liste des recettes</h2>

    <?php
    // Inclure le fichier de connexion à la base de données
    include 'connexion_base.php';

    // Requête SQL pour récupérer les recettes avec le nom d'utilisateur et le pays associés
    $id_utilisateur=$_SESSION['user'];
    $sql = "SELECT r.id_categorie AS id_categorie, r.id_region AS id_region, c.nom_categorie AS nom_categorie, r.id_recette AS id_recette, r.titre AS titre_recette, r.description AS description, u.nom AS nom_utilisateur, p.nom_region AS region_recette, p.pays AS pays_recette
            FROM projet_recette r
            INNER JOIN projet_utilisateur u ON r.id_utilisateur = u.id_utilisateur
            INNER JOIN projet_region p ON r.id_region = p.id_region
            INNER JOIN projet_categorie c ON r.id_categorie = c.id_categorie
            WHERE r.id_utilisateur = $id_utilisateur
            ORDER BY r.date_publication DESC
            ";

    // Préparation de la requête
    $stmt = $pdo->prepare($sql);

    // Exécution de la requête
    $stmt->execute();

    // Récupération des résultats
    $recettes = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $sql = "SELECT id_categorie, nom_categorie FROM projet_categorie";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $sql = "SELECT id_region, nom_region, pays FROM projet_region";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $regions = $stmt->fetchAll(PDO::FETCH_ASSOC);
    // Vérifier s'il y a des recettes
    if ($recettes) {
        // Afficher les recettes dans un tableau HTML
        echo '<table>';
        echo '<tr><th></th><th>Titre de la recette</th><th>Description</th><th>Catégorie</th><th>Region</th><th></th></tr>';
        foreach ($recettes as $recette) {
            echo '<form action="save_recette.php" method="post">';
            echo '<tr>';
            echo '<td hidden><input name="id_recette" type="text" value="' . $recette['id_recette'] . '"></td>';
            echo '<td><img width="140px" src="images_recettes/'. $recette['id_recette'] .'.jpg"></td>';
            echo '<td><input name="titre" type="text" value="' . $recette['titre_recette'] . '"></td>';
            echo '<td><textarea rows="4" cols="50" name="description" type="text" style="resize: none;">' . $recette['description'] . '</textarea></td>';
            echo '<td><select name="categorie">';
            foreach ($categories as $categorie) {
                echo '<option ';
                if($categorie['id_categorie']==$recette['id_categorie']){
                    echo'selected';
                }
                echo ' value="'. $categorie['id_categorie'] .'">'. $categorie['nom_categorie'] .'</option>';
            }        
            echo '</select></td>';
            echo '<td><select name="region">';
            foreach ($regions as $region) {
                echo '<option ';
                if($region['id_region']==$recette['id_region']){
                    echo'selected';
                }
                echo ' value="'. $region['id_region'] .'">'. $region['nom_region'] .', '. $region['pays'] .'</option>';
            }        
            echo '</select>';
            echo '<td><a><input type="submit" value="Enregistrer"></a></td>';
            echo '</form>';
            echo '</tr>';
        }
        echo '</table>';
    } else {
        // Afficher un message si aucune recette n'est trouvée
        echo 'Aucune recette trouvée.';
    }
    ?>
        <a href="ajouter_recette.php"><button>Ajouter recette</button></a>
    <p id="error-message"><?php
                                                if (isset($_GET['error'])){
                                                    echo '<div class="alert alert-danger" role="alert">' . htmlspecialchars($_GET['error']) . '</div>';
                                                }elseif (isset($_GET['success'])){
                                                    echo '<div class="alert alert-success" role="alert">' . htmlspecialchars($_GET['success']) . '</div>';
                                                }
                                                ?></p> <!-- Message d'erreur -->

                                            </section>  
                                            
                                        
</body>

</html>
