<?php
// Vérifier si l'utilisateur est connecté
session_start();
if (!isset($_SESSION['user'])) {
    // Rediriger vers la page de connexion si l'utilisateur n'est pas connecté
    header("Location: connexion.php");
    exit;
}
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "projet";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$user_id = $_SESSION['user'];

$sql = "SELECT nom, prenom, email, mot_de_passe FROM projet_utilisateur WHERE id_utilisateur = $user_id";
$result = $conn->query($sql);

if ($result->num_rows == 1) {
    // Fetch user details
    $row = $result->fetch_assoc();
    $nom = $row['nom'];
    $prenom = $row['prenom'];
    $email = $row['email'];
    $mot_de_passe = $row['mot_de_passe'];
} else {
    echo "User not found.";
}
$conn->close();

?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <link rel="icon" type="image/x-icon" href="images/logo.jpeg">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mon Profil</title>
    <link rel="stylesheet" href="css/style-monprofil.css">

</head>
<header>
<nav>
                <img src="images/logo.jpeg" alt="logo" class="logo"></img>
                <a href="index.php">
                    <h3>Accueil</h3>
                </a>
                <?php 
                if(isset($_SESSION["user"])){
                    echo '<a href="mes_recettes.php"><h3>Mes recettes</h3></a>';
                }else{
                    echo '<a href="recette.php"><h3>Recettes</h3></a>';
                }
                ?>


                <a href="apropos.php">
                    <h3>À Propos</h3>
                </a>
                <a href="contact.php">
                    <h3>contact</h3>
                </a>

                
                <?php 
                if(isset($_SESSION["user"])){
                    echo '<a href="monprofil.php"><h3>Mon Profil</h3></a>';
                }else{
                    echo '<a href="connexion.php"><h3>Se connecter</h3></a>';
                }
                if(isset($_SESSION["user"])){
                    echo '<a href="deconnexion.php"><h3>Se déconnecter</h3></a>';
                }
                ?>
            </nav>
</header>


<body>
    <div class="container">
        <form action="update_profile.php" method="post" class="box">
    <h1>Mon Profil</h1>
    <h3>Nom:</h3>
    <input type="text" name="nom" value="<?php echo $nom; ?>">
    <h3>Prénom:</h3>
    <input type="text" name="prenom" value="<?php echo $prenom; ?>">
    <h3>Email:</h3>
    <input type="email" name="email" value="<?php echo $email; ?>">
    <h3>Mot de passe :</h3>
    <input type="password" name="motdepasse" value="<?php echo $mot_de_passe; ?>">
    <input type="submit" value="Enregistrer">
    <p id="error-message"><?php
                                                if (isset($_GET['error'])){
                                                    echo '<div class="alert alert-danger" role="alert">' . htmlspecialchars($_GET['error']) . '</div>';
                                                }elseif (isset($_GET['success'])){
                                                    echo '<div class="alert alert-success" role="alert">' . htmlspecialchars($_GET['success']) . '</div>';
                                                }
                                                ?></p> <!-- Message d'erreur -->
</form>

    </div>
</body>

</html>
