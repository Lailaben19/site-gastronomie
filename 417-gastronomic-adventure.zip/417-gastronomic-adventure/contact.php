<?php 
session_start();
?>
<!DOCTYPE html>
<html lang="fr">

<head>
    <link rel="icon" type="image/x-icon" href="images/logo.jpeg">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact</title>
    <link rel="stylesheet" href="css/style-contact.css">

</head>

<body>

    <header>


    <nav>
                <img src="images/logo.jpeg" alt="logo" class="logo"></img>
                <a href="index.php">
                    <h3>Accueil</h3>
                </a>
                <?php 
                if(isset($_SESSION["user"])){
                    echo '<a href="mes_recettes.php"><h3>Mes recettes</h3></a>';
                }else{
                    echo '<a href="recette.php"><h3>Recettes</h3></a>';
                }
                ?>


                <a href="apropos.php">
                    <h3>À Propos</h3>
                </a>
                <a href="contact.php">
                    <h3>contact</h3>
                </a>

                
                <?php 
                if(isset($_SESSION["user"])){
                    echo '<a href="monprofil.php"><h3>Mon Profil</h3></a>';
                }else{
                    echo '<a href="connexion.php"><h3>Se connecter</h3></a>';
                }
                if(isset($_SESSION["user"])){
                    echo '<a href="deconnexion.php"><h3>Se déconnecter</h3></a>';
                }
                ?>
            </nav>

    </header>
    <section>
        

        <div class="contact-info">
            <h1>Nous Contacter</h1>
            <h3>N'hésitez pas à nous contacter via les réseaux sociaux :</h3>

            <ul class="social-icons">
                <li>
                    <a href="https://www.instagram.com/votrenom/" target="_blank">
                        <img src="images/instagram.png" alt="Instagram"> Instagram
                    </a>
                </li>
                <li>
                    <a href="mailto:votre@email.com">
                        <img src="images/email.png" alt="Email"> Email
                    </a>
                </li>
                <li>
                    <a href="https://twitter.com/votrenom" target="_blank">
                        <img src="images/twitter.png" alt="Twitter"> Twitter
                    </a>
                </li>
                <li>
                    <a href="https://www.facebook.com/@votrenom" target="_blank">
                        <img src="images/facebook.png" alt="Facebook"> Facebook
                    </a>
                </li>

                <li>
                    <a href="tel:+123456789">
                        <img src="images/telephone.png" alt="Téléphone">+33 (234) 567-89

                    </a>
                </li>
            </ul>
        </div>

        <div class="formulaire">
            <div class="formulaire-box">
                <h3>Ou remplissez le formulaire ci-dessous pour nous envoyer un message :</h3>
                </br>
                <form action="contact_send.php" method="post">
                    <label for="name">Nom :</label>
                    <input type="text" id="name" name="name" required>

                    <label for="email">Email :</label>
                    <input type="email" id="email" name="email" required>

                    <label for="message">Message :</label>
                    <textarea id="message" name="message" rows="4" required></textarea>

                    <input type="submit" value="Envoyer">
                    <p id="error-message"><?php
                                                if (isset($_GET['error'])){
                                                    echo '<div class="alert alert-danger" role="alert">' . htmlspecialchars($_GET['error']) . '</div>';
                                                }elseif (isset($_GET['success'])){
                                                    echo '<div class="alert alert-success" role="alert">' . htmlspecialchars($_GET['success']) . '</div>';
                                                }
                                                ?></p> <!-- Message d'erreur -->
                </form>
            </div>
        </div>
    </section>

    <footer class="footer">
    <div class="footer-container">
        <div class="footer-section">
            <h3>Gastronomic Adventure</h3>
            <p>Explorez de nouvelles aventures gastronomiques avec nous !</p>
        </div>
        <div class="footer-section">
            <h3>Restons connectés</h3>
            <ul class="social-media">
                <li><a href="instagram.html"><i class="fab fa-instagram"></i> Instagram</a></li>
                <li><a href="facebook.html"><i class="fab fa-facebook"></i> Facebook</a></li>
                <li><a href="tiktok.html"><i class="fab fa-tiktok"></i> TikTok</a></li>
            </ul>
        </div>
        <div class="footer-section">
            <h3>Contactez-nous</h3>
            <ul class="contact-info">
                <li><i class="fas fa-envelope"></i> Email: contact@gastronomicadventure.com</li>
                <li><i class="fas fa-phone"></i> Téléphone: +33 (234) 567-89</li>
                <li><i class="fas fa-map-marker-alt"></i> Adresse: 123 Rue Principale, Bordeaux</li>
            </ul>
        </div>
    </div>
</footer>
</body>

</html>