<?php 
session_start();
?>
<!DOCTYPE html>
<html lang="fr">

<head>
    <link rel="icon" type="image/x-icon" href="images/logo.jpeg">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recettes</title>
    <link rel="stylesheet" href="css/style-recette.css">

    
</head>

<header>
    <header>
<nav>
                <img src="images/logo.jpeg" alt="logo" class="logo"></img>
                <a href="index.php">
                    <h3>Accueil</h3>
                </a>
                <?php 
                if(isset($_SESSION["user"])){
                    echo '<a href="mes_recettes.php"><h3>Mes recettes</h3></a>';
                }else{
                    echo '<a href="recette.php"><h3>Recettes</h3></a>';
                }
                ?>


                <a href="apropos.php">
                    <h3>À Propos</h3>
                </a>
                <a href="contact.php">
                    <h3>contact</h3>
                </a>

                
                <?php 
                if(isset($_SESSION["user"])){
                    echo '<a href="monprofil.php"><h3>Mon Profil</h3></a>';
                }else{
                    echo '<a href="connexion.php"><h3>Se connecter</h3></a>';
                }
                if(isset($_SESSION["user"])){
                    echo '<a href="deconnexion.php"><h3>Se déconnecter</h3></a>';
                }
                ?>
            </nav>
            </header>
</header>

<body>
    <section>
    <h2>Liste des recettes</h2>
    <?php
    // Inclure le fichier de connexion à la base de données
    include 'connexion_base.php';

    // Requête SQL pour récupérer les recettes avec le nom d'utilisateur et le pays associés
    $sql = "SELECT c.nom_categorie AS nom_categorie, r.id_recette AS id_recette, r.titre AS titre_recette, r.description AS description, u.nom AS nom_utilisateur, p.nom_region AS region_recette, p.pays AS pays_recette
            FROM projet_recette r
            INNER JOIN projet_utilisateur u ON r.id_utilisateur = u.id_utilisateur
            INNER JOIN projet_region p ON r.id_region = p.id_region
            INNER JOIN projet_categorie c ON r.id_categorie = c.id_categorie
            ORDER BY r.date_publication DESC
            ";

    // Préparation de la requête
    $stmt = $pdo->prepare($sql);

    // Exécution de la requête
    $stmt->execute();

    // Récupération des résultats
    $recettes = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Vérifier s'il y a des recettes
    if ($recettes) {
        // Afficher les recettes dans un tableau HTML
        echo '<table>';
        echo '<tr><th></th><th>Titre de la recette</th><th>Description</th><th>Catégorie</th><th>Ajouté par</th><th>Pays</th><th>Region</th></tr>';
        foreach ($recettes as $recette) {
            echo '<tr>';
            echo '<td><img width="140px" src="images_recettes/'. $recette['id_recette'] .'.jpg"></td>';
            echo '<td>' . $recette['titre_recette'] . '</td>';
            echo '<td>' . $recette['description'] . '</td>';
            echo '<td>' . $recette['nom_categorie'] . '</td>';
            echo '<td>' . $recette['nom_utilisateur'] . '</td>';
            echo '<td>' . $recette['pays_recette'] . '</td>';
            echo '<td>' . $recette['region_recette'] . '</td>';
            echo '</tr>';
        }
        echo '</table>';
    } else {
        // Afficher un message si aucune recette n'est trouvée
        echo 'Aucune recette trouvée.';
    }
    ?>

</section>

    

<footer class="footer">
    <div class="footer-container">
        <div class="footer-section">
            <h3>Gastronomic Adventure</h3>
            <p>Explorez de nouvelles aventures gastronomiques avec nous !</p>
        </div>
        <div class="footer-section">
            <h3>Restons connectés</h3>
            <ul class="social-media">
                <li><a href="instagram.html"><i class="fab fa-instagram"></i> Instagram</a></li>
                <li><a href="facebook.html"><i class="fab fa-facebook"></i> Facebook</a></li>
                <li><a href="tiktok.html"><i class="fab fa-tiktok"></i> TikTok</a></li>
            </ul>
        </div>
        <div class="footer-section">
            <h3>Contactez-nous</h3>
            <ul class="contact-info">
                <li><i class="fas fa-envelope"></i> Email: contact@gastronomicadventure.com</li>
                <li><i class="fas fa-phone"></i> Téléphone: +33 (234) 567-89</li>
                <li><i class="fas fa-map-marker-alt"></i> Adresse: 123 Rue Principale, Bordeaux</li>
            </ul>
        </div>
    </div>
</footer>

</body>

</html>
