<?php
// Start session
session_start();

// Check if user is logged in
if (!isset($_SESSION['user'])) {
    // Redirect to login page
    header("Location: connexion.php");
    exit();
}

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "projet";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get user ID from session
$user_id = $_SESSION['user'];

// Extract updated profile information from POST data
$nom = $_POST['nom'];
$prenom = $_POST['prenom'];
$email = $_POST['email'];
$mot_de_passe = $_POST['motdepasse'];

// Update user profile in the database
$sql = "UPDATE projet_utilisateur SET nom='$nom', prenom='$prenom', email='$email', mot_de_passe='$mot_de_passe' WHERE id_utilisateur=$user_id";

if ($conn->query($sql) === TRUE) {
    // Inform user that profile information has been updated
    header('Location: monprofil.php?error=Informations enregistrées.');
} else {
    // If an error occurs during update, inform the user
    header('Location: monprofil.php?error=Erreur lors de l\'enregistrement des informations.');
}

// Close connection
$conn->close();
?>
