<?php
       
        // Vérifier si le formulaire a été soumis
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Database connection
        $servername = "localhost";
        $username = "root";
        $password = ""; // si Wampserver, mettez "" ici
        $dbname = "projet";
        if (substr($_SERVER['SERVER_NAME'],-17) == "emi.u-bordeaux.fr")
        {
            $servername = "mariadb";
            $username = "lbenhaddou";
            $password = "Laila2001";
            $dbname = "lbenhaddou";
        }

        try {
            $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            // Récupérer les données du formulaire
            $nom = $_POST['name'];
            $email = $_POST['email'];
            $message = $_POST['message'];

            // Préparer la requête d'insertion
            $stmt = $conn->prepare("INSERT INTO projet_messages_contact (nom, email, message, date_message) VALUES ('$nom', '$email', '$message',NOW())");
            // Exécuter la requête
            $stmt->execute();
            // Redirection vers une page de confirmation
            header("Location: contact.php?success=Message envoyé avec succes.");
            exit();
        } catch(PDOException $e) {
            // Gérer les erreurs de connexion à la base de données
            echo "Erreur de connexion à la base de données: " . $e->getMessage();
        }
        }
        $conn = null;
        ?>