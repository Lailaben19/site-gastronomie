<?php
// Vérifier si le formulaire a été soumis
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Vérifier si les données nécessaires sont présentes dans la requête POST
    if (isset($_POST['id_recette']) && isset($_POST['commentaire'])) {
        // Inclure le fichier de connexion à la base de données
        require_once("connexion_base.php");

        // Récupérer les données du formulaire
        $id_recette = $_POST['id_recette'];
        $commentaire = $_POST['commentaire'];

        // Préparer la requête d'insertion
        $requete = "INSERT INTO commentaires (id_recette, commentaire) VALUES (?, ?)";
        $stmt = $pdo->prepare($requete);

        // Exécuter la requête avec les valeurs des paramètres
        $stmt->execute([$id_recette, $commentaire]);

        // Rediriger l'utilisateur vers la page précédente après l'ajout du commentaire
        header("Location: {$_SERVER['HTTP_REFERER']}");
        exit();
    } else {
        // Si les données nécessaires ne sont pas présentes, afficher un message d'erreur
        echo "Erreur : Données manquantes pour ajouter le commentaire.";
    }
} else {
    // Si la requête n'est pas de type POST, rediriger l'utilisateur vers la page précédente
    header("Location: {$_SERVER['HTTP_REFERER']}");
    exit();
}
?>
