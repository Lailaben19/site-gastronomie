<?php 
session_start();
?>
<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>a propos de nous </title>
    <link rel="stylesheet" href="css/style-apropos.css">

    <link rel="icon" type="image/x-icon" href="images/logo.jpeg">
    
</head>

<header>
    <header>

    <nav>
                <img src="images/logo.jpeg" alt="logo" class="logo"></img>
                <a href="index.php">
                    <h3>Accueil</h3>
                </a>
                
                <?php 
                if(isset($_SESSION["user"])){
                    echo '<a href="mes_recettes.php"><h3>Mes recettes</h3></a>';
                }else{
                    echo '<a href="recette.php"><h3>Recettes</h3></a>';
                }
                ?>


                <a href="apropos.php">
                    <h3>À Propos</h3>
                </a>
                <a href="contact.php">
                    <h3>contact</h3>
                </a>

                
                <?php 
                if(isset($_SESSION["user"])){
                    echo '<a href="monprofil.php"><h3>Mon Profil</h3></a>';
                }else{
                    echo '<a href="connexion.php"><h3>Se connecter</h3></a>';
                }
                if(isset($_SESSION["user"])){
                    echo '<a href="deconnexion.php"><h3>Se déconnecter</h3></a>';
                }
                ?>
            </nav>
    </header>
</header>

<body>

<section>
    <h2> À propos de Gastronomic Adventure</h2>
    <p> Bienvenue sur Gastronomic Adventure, votre destination en ligne pour explorer les délices culinaires du monde entier !</p>
    <h2> notre mission </h2>
    <p> Chez Gastronomic Adventure, notre mission est de vous emmener dans un voyage gustatif à travers les cultures du monde. Nous croyons que la nourriture est bien plus qu'une simple nécessité - elle est le reflet de l'identité, de l'histoire et de la
        diversité de chaque région et chaque communauté. Notre objectif est de célébrer cette richesse culinaire en offrant une plateforme où les passionnés de cuisine peuvent partager leurs spécialités, leurs techniques et leurs histoires avec le monde
        entier.
    </p>
    <h2> Qui Sommes-Nous</h2>
    <p>Gastronomic Adventure est né de la passion de trois étudiantes, lynda , laila et hadil , chacune d'entre elles vient d'une region differente , et chacune a sa propre culture culinaire , elles ont commence a s'echanger des recettes jusqu'a avoir l'idée
        de Gastronomic adventure </p>
    <h2>Rejoignez-nous dans cette Aventure Culinaire !</h2>
    <p> Bienvenue à bord de Gastronomic Adventure - où chaque repas est une nouvelle aventure ! n'hesiter pas a vous inscrire pour ne pas en perdre une miete ...!
    </p>

            </section>

            
            <footer class="footer">
    <div class="footer-container">
        <div class="footer-section">
            <h3>Gastronomic Adventure</h3>
            <p>Explorez de nouvelles aventures gastronomiques avec nous !</p>
        </div>
        <div class="footer-section">
            <h3>Restons connectés</h3>
            <ul class="social-media">
                <li><a href="instagram.html"><i class="fab fa-instagram"></i> Instagram</a></li>
                <li><a href="facebook.html"><i class="fab fa-facebook"></i> Facebook</a></li>
                <li><a href="tiktok.html"><i class="fab fa-tiktok"></i> TikTok</a></li>
            </ul>
        </div>
        <div class="footer-section">
            <h3>Contactez-nous</h3>
            <ul class="contact-info">
                <li><i class="fas fa-envelope"></i> Email: contact@gastronomicadventure.com</li>
                <li><i class="fas fa-phone"></i> Téléphone: +33 (234) 567-89</li>
                <li><i class="fas fa-map-marker-alt"></i> Adresse: 123 Rue Principale, Bordeaux</li>
            </ul>
        </div>
    </div>
</footer>

</body>

</html>