<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user'])) {
    // Redirect to login page or handle unauthorized access
    header("Location: connexion.php");
    exit();
}

// Database connection
    $config_base['hote'] = "localhost";
    $config_base['utilisateur'] = "root";
    $config_base['motdepasse'] = ""; // si Wampserver, mettez "" ici
    $config_base['nom_base'] = "projet";
    if (substr($_SERVER['SERVER_NAME'],-17) == "emi.u-bordeaux.fr")
    {
    $config_base['hote'] = "mariadb";
    $config_base['utilisateur'] = "lbenhaddou";
    $config_base['motdepasse'] = "Laila2001";
    $config_base['nom_base'] = "lbenhaddou";
    }

// Create connection
$conn = new mysqli($config_base['hote'], $config_base['utilisateur'], $config_base['motdepasse'], $config_base['nom_base']);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Prepare data for insertion
    $titre = $_POST['titre'];
    $description = $_POST['description'];
    $id_categorie = $_POST['categorie'];
    $id_region = $_POST['region'];
    $id_utilisateur = $_SESSION['user']; // Get user ID from session

    // Insert data into projet_recette table
    $sql = "INSERT INTO projet_recette (titre, description, id_utilisateur, id_categorie, id_region, date_publication) 
            VALUES ('$titre', '$description', $id_utilisateur, $id_categorie, $id_region, NOW())";

    if ($conn->query($sql) === TRUE) {
        // Get the ID of the last inserted record
        $id_recette = $conn->insert_id;
        
        $file = $_FILES['file'];
        $fileName = $id_recette . '.jpg';
        $destination_folder = $_POST["destination_folder"];
        $destination = $destination_folder . $fileName;
    
        if (move_uploaded_file($file['tmp_name'], $destination)) {
            header("Location: ajouter_recette.php?success=Recette ajoutée avec succès.");
        }

        exit();

    } else {
        // Error occurred while inserting record
        header("Location: ajouter_recette.php?error=Erreur:".$conn->error);
    }
}

// Close connection
$conn->close();
?>
