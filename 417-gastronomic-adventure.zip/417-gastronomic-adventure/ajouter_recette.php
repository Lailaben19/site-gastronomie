<?php 
session_start();
if (!isset($_SESSION['user'])){
    header("Location: connexion.php?error=Vous devez vous connecter pour accéder à cette page.");
}
?>
<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recettes</title>
    <link rel="stylesheet" href="css/style-ajouter_recette.css">

</head>

        <header>
        <nav>
                <img src="images/logo.jpeg" alt="logo" class="logo"></img>
                <a href="index.php">
                    <h3>Accueil</h3>
                </a>
                <?php 
                if(isset($_SESSION["user"])){
                    echo '<a href="mes_recettes.php"><h3>Mes recettes</h3></a>';
                }else{
                    echo '<a href="recette.php"><h3>Recettes</h3></a>';
                }
                ?>


                <a href="apropos.php">
                    <h3>À Propos</h3>
                </a>
                <a href="contact.php">
                    <h3>contact</h3>
                </a>

                
                <?php 
                if(isset($_SESSION["user"])){
                    echo '<a href="monprofil.php"><h3>Mon Profil</h3></a>';
                }else{
                    echo '<a href="connexion.php"><h3>Se connecter</h3></a>';
                }
                if(isset($_SESSION["user"])){
                    echo '<a href="deconnexion.php"><h3>Se déconnecter</h3></a>';
                }
                ?>
            </nav>
</header>

<body>
    <section>
    <h2>Ajouter recette</h2>
    <?php
    // Inclure le fichier de connexion à la base de données
    include 'connexion_base.php';

    // Requête SQL pour récupérer les recettes avec le nom d'utilisateur et le pays associés
    $id_utilisateur=$_SESSION['user'];

    $sql = "SELECT id_categorie, nom_categorie FROM projet_categorie";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $sql = "SELECT id_region, nom_region, pays FROM projet_region";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $regions = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    ?>
        <table>
        <tr><th>Image</th><th>Titre de la recette</th><th>Description</th><th>Catégorie</th><th>Region</th><th></th></tr>
        
            <form action="ajouter_recette_bd.php" method="post" enctype="multipart/form-data">
             <tr>
             <td hidden><input name="id_recette" type="text"></td>
             <td>
                <input type="file" name="file" id="edit-image-input" accept=".jpg">
                <input type="hidden" name="destination_folder" value="images_recettes/">
                </td>
             <td><input name="titre" type="text" placeholder="..."></td>
             <td><textarea rows="4" cols="50" placeholder="..." name="description" type="text" style="resize: none;"></textarea></td>
             <td><select name="categorie">
                <?php
            foreach ($categories as $categorie) {
                echo '<option value="'. $categorie['id_categorie'] .'">'. $categorie['nom_categorie'] .'</option>';
            }        
            echo '</select></td>';
            echo '<td><select name="region">';
            foreach ($regions as $region) {
                echo '<option value="'. $region['id_region'] .'">'. $region['nom_region'] .', '. $region['pays'] .'</option>';
            }        
            echo '</select>';
            ?>
            <td><a><input type="submit" value="Ajouter"></a></td>
             </form>
             </tr>
        </table>
    <p id="error-message"><?php
                                                if (isset($_GET['error'])){
                                                    echo '<div class="alert alert-danger" role="alert">' . htmlspecialchars($_GET['error']) . '</div>';
                                                }elseif (isset($_GET['success'])){
                                                    echo '<div class="alert alert-success" role="alert">' . htmlspecialchars($_GET['success']) . '</div>';
                                                }
                                                ?></p> <!-- Message d'erreur -->
                                                </section>
</body>

</html>
