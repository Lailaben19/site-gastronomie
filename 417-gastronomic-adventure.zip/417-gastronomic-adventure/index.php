<?php 
session_start();
?>
<!DOCTYPE html>
<html lang="fr">

<head>
    <link rel="icon" type="image/x-icon" href="images/logo.jpeg">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gastronomic Adventure </title>
    <link rel="stylesheet" href="css/style-index.css">

    
</head>

<body>

    <header>
        <header>

            <nav>
                <img src="images/logo.jpeg" alt="logo" class="logo"></img>
                <a href="index.php">
                    <h3>Accueil</h3>
                </a>
                <?php 
                if(isset($_SESSION["user"])){
                    echo '<a href="mes_recettes.php"><h3>Mes recettes</h3></a>';
                }else{
                    echo '<a href="recette.php"><h3>Recettes</h3></a>';
                }
                ?>


                <a href="apropos.php">
                    <h3>À Propos</h3>
                </a>
                <a href="contact.php">
                    <h3>contact</h3>
                </a>

                
                <?php 
                if(isset($_SESSION["user"])){
                    echo '<a href="monprofil.php"><h3>Mon Profil</h3></a>';
                }else{
                    echo '<a href="connexion.php"><h3>Se connecter</h3></a>';
                }
                if(isset($_SESSION["user"])){
                    echo '<a href="deconnexion.php"><h3>Se déconnecter</h3></a>';
                }
                ?>
            </nav>
        </header>
    </header>
    <section class="carousel-container">
    <div class="carousel">
        <input type="radio" id="slide1" name="slide" checked> <!-- Ajoutez checked ici -->
        <input type="radio" id="slide2" name="slide">
        <input type="radio" id="slide3" name="slide">

        <div class="slides">
            <div class="slide slide1">
                <img src="images/img1.png" alt="Image 1">
            </div>
            <div class="slide slide2">
                <img src="images/img2.png" alt="Image 2">
            </div>
            <div class="slide slide3">
                <img src="images/img3.png" alt="Image 3">
            </div>
        </div>

        <div class="navigation">
            <label for="slide1"></label>
            <label for="slide2"></label>
            <label for="slide3"></label>
        </div>
    </div>
    <script src="script.js"></script>

            </section>


            <footer class="footer">
    <div class="footer-container">
        <div class="footer-section">
            <h3>Gastronomic Adventure</h3>
            <p>Explorez de nouvelles aventures gastronomiques avec nous !</p>
        </div>
        <div class="footer-section">
            <h3>Restons connectés</h3>
            <ul class="social-media">
                <li><a href="instagram.html"><i class="fab fa-instagram"></i> Instagram</a></li>
                <li><a href="facebook.html"><i class="fab fa-facebook"></i> Facebook</a></li>
                <li><a href="tiktok.html"><i class="fab fa-tiktok"></i> TikTok</a></li>
            </ul>
        </div>
        <div class="footer-section">
            <h3>Contactez-nous</h3>
            <ul class="contact-info">
                <li><i class="fas fa-envelope"></i> Email: contact@gastronomicadventure.com</li>
                <li><i class="fas fa-phone"></i> Téléphone: +33 (234) 567-89</li>
                <li><i class="fas fa-map-marker-alt"></i> Adresse: 123 Rue Principale, Bordeaux</li>
            </ul>
        </div>
    </div>
</footer>




</body>

</html>