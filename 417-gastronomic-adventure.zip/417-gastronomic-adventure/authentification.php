<?php
// Start session
session_start();

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Database connection
    $config_base['hote'] = "localhost";
    $config_base['utilisateur'] = "root";
    $config_base['motdepasse'] = ""; // si Wampserver, mettez "" ici
    $config_base['nom_base'] = "projet";
    if (substr($_SERVER['SERVER_NAME'],-17) == "emi.u-bordeaux.fr")
    {
    $config_base['hote'] = "mariadb";
    $config_base['utilisateur'] = "lbenhaddou";
    $config_base['motdepasse'] = "Laila2001";
    $config_base['nom_base'] = "lbenhaddou";
    }

    // Create connection
    $conn = new mysqli($config_base['hote'], $config_base['utilisateur'], $config_base['motdepasse'], $config_base['nom_base']);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Sanitize input to prevent SQL injection
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['motdepasse']);

    // Query to check if user exists
    $sql = "SELECT id_utilisateur FROM projet_utilisateur WHERE email='$email' AND mot_de_passe='$password'";
    $result = $conn->query($sql);

    if ($result->num_rows == 1) {
        // User exists, create session
        $row = $result->fetch_assoc();
        $_SESSION['user'] = $row['id_utilisateur'];
        // Redirect to dashboard or any other page
        header("Location: index.php");
        exit();
    } else {
        // User doesn't exist, set error message
        header('Location: connexion.php?error=Login ou mot de passe incorrect.');
    }

    // Close connection
    $conn->close();
}
?>