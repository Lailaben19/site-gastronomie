<?php
// Définition des paramètres de connexion à la base de données
$config_base = [
    'local' => [
        'hote'        => 'localhost',
        'utilisateur' => 'root',
        'motdepasse'  => 'root',
        'nom_base'    => 'projet'
    ],
    'serveur' => [
        'hote'        => 'mariadb',
        'utilisateur' => 'lbenhaddou',
        'motdepasse'  => 'Laila2001',
        'nom_base'    => 'lbenhaddou'
    ]
];
