<?php 
session_start();
if (isset($_SESSION['user'])){
    header("Location: index.php");
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <link rel="icon" type="image/x-icon" href="images/logo.jpeg">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inscription</title>
    <link rel="stylesheet" href="css/style-inscription.css">
   
</head> 
<body>
<header>
           
<nav>
                <img src="images/logo.jpeg" alt="logo" class="logo"></img>
                <a href="index.php">
                    <h3>Accueil</h3>
                </a>
                <?php 
                if(isset($_SESSION["user"])){
                    echo '<a href="mes_recettes.php"><h3>Mes recettes</h3></a>';
                }else{
                    echo '<a href="recette.php"><h3>Recettes</h3></a>';
                }
                ?>


                <a href="apropos.php">
                    <h3>À Propos</h3>
                </a>
                <a href="contact.php">
                    <h3>contact</h3>
                </a>

                
                <?php 
                if(isset($_SESSION["user"])){
                    echo '<a href="monprofil.php"><h3>Mon Profil</h3></a>';
                }else{
                    echo '<a href="connexion.php"><h3>Se connecter</h3></a>';
                }
                if(isset($_SESSION["user"])){
                    echo '<a href="deconnexion.php"><h3>Se déconnecter</h3></a>';
                }
                ?>
            </nav>
</header>
<section>
    <?php
    // Vérifier si le formulaire a été soumis
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Récupérer les données soumises dans le formulaire
        $nom = $_POST["nom"];
        $prenom = $_POST["prenom"];
        $email = $_POST["mail"];
        $mot_de_passe = $_POST["mot_de_passe"];


        $servername = "localhost";
        $username = "root";
        $password = ""; // si Wampserver, mettez "" ici
        $dbname = "projet";
        if (substr($_SERVER['SERVER_NAME'],-17) == "emi.u-bordeaux.fr")
        {
            $servername = "mariadb";
            $username = "lbenhaddou";
            $password = "Laila2001";
            $dbname = "lbenhaddou";
        }

        try {
            $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
            // Définir le mode d'erreur PDO à exception
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
            // Vérifier si l'email existe déjà dans la base de données
            $stmt = $conn->prepare("SELECT COUNT(*) FROM projet_utilisateur WHERE email = :email");
            $stmt->bindParam(':email', $email);
            $stmt->execute();
            $count = $stmt->fetchColumn();
        
            if ($count > 0) {
                // L'email existe déjà, afficher un message d'erreur
                echo "Cet email est déjà utilisé. Veuillez utiliser une autre adresse email.";
            } else {
                // L'email n'existe pas, insérer les données dans la base de données
                $stmt = $conn->prepare("INSERT INTO projet_utilisateur (nom, prenom, email, mot_de_passe,date_inscription) VALUES (:nom, :prenom, :email, :mot_de_passe, NOW())");
                // Liaison des paramètres avec les valeurs
                $stmt->bindParam(':nom', $nom);
                $stmt->bindParam(':prenom', $prenom);
                $stmt->bindParam(':email', $email);
                $stmt->bindParam(':mot_de_passe', $mot_de_passe);

        
                // Exécuter la requête
                $stmt->execute();
            

                
            }
            
        } catch(PDOException $e) {
            // Gérer les erreurs de connexion à la base de données
            echo "Erreur de connexion à la base de données: " . $e->getMessage();
        }
        

        // Fermer la connexion à la base de données
        $conn = null;
    }
    ?>
    <form class="box" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        <h1>Inscription</h1>
        <h3>nom:</h3><input type="text" id="nom" name="nom" > 
        <h3>prenom:</h3><input type="text" id="prenom" name="prenom" > 
        <h3>email :</h3><input type="email" id="mail" name="mail" >
        <h3>mot de passe :</h3><input type="password" id="mot_de_passe" name="mot_de_passe" >
        <input type="submit" value="S'inscrire">
        <p>Vous avez déjà un compte ?</p>
        <a href="connexion.php">Connectez-vous</a>
    </form>
</section>
</body>
</html>
