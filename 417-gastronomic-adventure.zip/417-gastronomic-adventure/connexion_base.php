<?php
$host = "localhost";
$username = "root";
$password = ""; // si Wampserver, mettez "" ici
$dbname = "projet";
if (substr($_SERVER['SERVER_NAME'],-17) == "emi.u-bordeaux.fr")
{
    $host = "mariadb";
    $username = "lbenhaddou";
    $password = "Laila2001";
    $dbname = "lbenhaddou";
}
// Tentative de connexion à la base de données
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    // Configuration supplémentaire si nécessaire
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    $pdo->exec("set names utf8"); // Définit le jeu de caractères à UTF-8
} catch (PDOException $e) {
    // En cas d'erreur de connexion, affichez l'erreur
    echo "Erreur de connexion : " . $e->getMessage();
    // Arrêtez l'exécution du script
    die();
}
?>
